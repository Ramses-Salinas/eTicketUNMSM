from flask import Flask, render_template, jsonify
import mysql.connector
import datetime
import base64
import requests
import pyodbc
import psycopg2

app = Flask(__name__)

host = "c.clu.postgres.database.azure.com"
dbname = "citus"
user = "citus"
password = "Admin1234"
sslmode = "require"

# Construct connection string

conn_string = "host={0} user={1} dbname={2} password={3} sslmode={4}".format(host, user, dbname, password, sslmode)
conn = psycopg2.connect(conn_string)
print("Connection established")

@app.route('/main')
def main_content():
    # Realiza una solicitud GET a la ruta /menu
    response = requests.get('http://localhost:4000/menu')

    # Verifica si la solicitud fue exitosa (código de respuesta 200)
    if response.status_code == 200:
        # Obtiene los datos del menú en formato JSON
        menu_data = response.json()

        # Renderiza el archivo mainContent.html y pasa los datos del menú como argumento
        return render_template('mainContent.html', menu=menu_data)

    # Si la solicitud no fue exitosa, muestra un mensaje de error
    return 'Error al obtener el menú del día'

@app.route('/ticket')
def ticket():
    return render_template('Ticket.html')


@app.route('/menu')
def obtener_menu_dia():
    # Obten la fecha actual
    fecha_actual = datetime  # Aqui puedes utilizar la fecha actual en lugar de una fecha fija

    try:
        # Crea un cursor para ejecutar consultas
        # cursor = conn.cursor()
        cursor = conn.cursor()
        # Ejecuta la consulta para obtener el menu del dia
        cursor.execute("""
            SELECT m.Fecha,
                   d.Bebida, d.Fruta, d.Acompanamiento, d.ImagenDesayuno,
                   a.Entrada, a.Refresco, a.PlatoFondo, a.Fruta, a.ImagenAlmuerzo,
                   c.PlatoFondo, c.Refresco, c.Postre, c.ImagenCena
            FROM Menu m
            JOIN Desayuno d ON m.ID = d.MenuID
            JOIN Almuerzo a ON m.ID = a.MenuID
            JOIN Cena c ON m.ID = c.MenuID
            WHERE m.Fecha = ?
        """, fecha_actual)

        # Obtiene los resultados de la consulta
        menu = cursor.fetchone()

        # Verifica si se encontro el menu del dia
        if menu is None:
            return jsonify({'mensaje': 'No se encontro el menu del dia'})

        # Convierte los datos del menu en un diccionario
        menu_dict = {
            'fecha': str(menu.Fecha),
            'desayuno': {
                'bebida': menu.Bebida,
                'fruta': menu.Fruta,
                'acompanamiento': menu.Acompanamiento,
                'imagen_desayuno': base64.b64encode(menu.ImagenDesayuno).decode('utf-8')
            },
            'almuerzo': {
                'entrada': menu.Entrada,
                'refresco': menu.Refresco,
                'plato_fondo': menu.PlatoFondo,
                'fruta': menu.Fruta,
                'imagen_almuerzo': base64.b64encode(menu.ImagenAlmuerzo).decode('utf-8')
            },
            'cena': {
                'plato_fondo': menu.PlatoFondo,
                'refresco': menu.Refresco,
                'postre': menu.Postre,
                'imagen_cena': base64.b64encode(menu.ImagenCena).decode('utf-8')
            }
        }
        # Devuelve el menu del dia en formato JSON
        return jsonify(menu_dict)

    except pyodbc.Error as e:

        return jsonify({'error': str(e)})


@app.route('/')
def index():
    return render_template('Login.html')

@app.route('/register')
def register():
    return render_template('Register.html')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=4000, debug=True)
